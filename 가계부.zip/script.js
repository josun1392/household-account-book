const STORAGE_KEY = "household-account-book-transactions";

const categoriesByType = {
  expense: [
    "식비",
    "카페",
    "교통",
    "쇼핑",
    "취미",
    "구독",
    "생활",
    "기타",
  ],
  income: [
    "급여",
    "용돈",
    "아르바이트",
    "환급",
    "기타",
  ],
};

const expenseChartColors = [
  "#bb4d32",
  "#d07a2a",
  "#dfb04a",
  "#6e9a3d",
  "#2f8f83",
  "#4a7fc9",
  "#7355b6",
  "#a95d8f",
];

const incomeChartColors = [
  "#1f7a53",
  "#3f9b73",
  "#78b159",
  "#2f8f83",
  "#4a7fc9",
];

const form = document.getElementById("transactionForm");
const dateInput = document.getElementById("date");
const todayButton = document.getElementById("todayButton");
const typeInput = document.getElementById("type");
const amountInput = document.getElementById("amount");
const categoryInput = document.getElementById("category");
const memoInput = document.getElementById("memo");
const isFixedInput = document.getElementById("isFixed");
const transactionList = document.getElementById("transactionList");
const transactionCount = document.getElementById("transactionCount");
const transactionSearchInput = document.getElementById("transactionSearch");
const emptyState = document.getElementById("emptyState");
const summarySection = document.getElementById("summary");
const formEyebrow = document.getElementById("formEyebrow");
const formStatus = document.getElementById("formStatus");
const submitButton = document.getElementById("submitButton");
const cancelEditButton = document.getElementById("cancelEditButton");
const statisticsTypeInput = document.getElementById("statisticsType");
const statisticsEmpty = document.getElementById("statisticsEmpty");
const statisticsList = document.getElementById("statisticsList");
const pieChart = document.getElementById("pieChart");
const chartTitle = document.getElementById("chartTitle");
const chartTotal = document.getElementById("chartTotal");
const totalIncomeElement = document.getElementById("totalIncome");
const totalExpenseElement = document.getElementById("totalExpense");
const balanceElement = document.getElementById("balance");
const totalFixedExpenseElement = document.getElementById("totalFixedExpense");
const totalVariableExpenseElement = document.getElementById("totalVariableExpense");
const monthFilterInput = document.getElementById("monthFilter");
const selectedPeriodLabel = document.getElementById("selectedPeriodLabel");
const periodToggleButton = document.getElementById("periodToggleButton");
const periodSelectionPanel = document.getElementById("periodSelectionPanel");
const allTimeButton = document.getElementById("allTimeButton");
const thisMonthButton = document.getElementById("thisMonthButton");
const prevYearButton = document.getElementById("prevYearButton");
const nextYearButton = document.getElementById("nextYearButton");
const periodMonthGrid = document.getElementById("periodMonthGrid");
const periodPanelYearLabel = document.getElementById("periodPanelYearLabel");
const summaryModal = document.getElementById("summaryModal");
const modalTitle = document.getElementById("modalTitle");
const modalBody = document.getElementById("modalBody");
const modalTotal = document.getElementById("modalTotal");
const modalCloseButton = document.getElementById("modalCloseButton");

let transactions = loadTransactions();
let editingTransactionId = null;

const periodState = {
  value: "all",
  isPanelOpen: false,
  panelYear: getCurrentYear(),
};

initializeApp();

function initializeApp() {
  dateInput.value = getTodayString();
  updateCategoryOptions(typeInput.value);
  syncMonthFilterOptions();
  setPeriodValue("all", { closePanel: false, skipRender: true });
  render();

  typeInput.addEventListener("change", handleTypeChange);
  form.addEventListener("submit", handleSubmit);
  amountInput.addEventListener("input", handleAmountInput);
  todayButton.addEventListener("click", handleTodayButtonClick);
  cancelEditButton.addEventListener("click", resetForm);
  transactionSearchInput.addEventListener("input", render);
  statisticsTypeInput.addEventListener("change", renderStatistics);
  monthFilterInput.addEventListener("change", handleNativeMonthFilterChange);
  periodToggleButton.addEventListener("click", togglePeriodPanel);
  allTimeButton.addEventListener("click", () => setPeriodValue("all"));
  thisMonthButton.addEventListener("click", handleThisMonthClick);
  prevYearButton.addEventListener("click", () => changePanelYear(-1));
  nextYearButton.addEventListener("click", () => changePanelYear(1));
  periodMonthGrid.addEventListener("click", handlePeriodMonthClick);
  transactionList.addEventListener("click", handleTransactionAction);
  summarySection.addEventListener("click", handleSummaryCardClick);
  summarySection.addEventListener("keydown", handleSummaryCardKeydown);
  summaryModal.addEventListener("click", handleModalOverlayClick);
  modalCloseButton.addEventListener("click", closeSummaryModal);
  document.addEventListener("keydown", handleDocumentKeydown);
}

function handleTypeChange() {
  if (typeInput.value !== "expense") {
    isFixedInput.checked = false;
  }

  updateCategoryOptions(typeInput.value);
}

function handleSubmit(event) {
  event.preventDefault();

  const amount = parseAmountInputValue(amountInput.value);
  if (!Number.isFinite(amount) || amount <= 0) {
    amountInput.focus();
    return;
  }

  const transaction = {
    id: editingTransactionId ?? createTransactionId(),
    date: dateInput.value,
    type: typeInput.value,
    amount,
    category: categoryInput.value,
    memo: memoInput.value.trim(),
    isFixed: typeInput.value === "expense" ? isFixedInput.checked : false,
  };

  if (editingTransactionId) {
    transactions = transactions.map((currentTransaction) =>
      currentTransaction.id === editingTransactionId ? transaction : currentTransaction,
    );
  } else {
    transactions.push(transaction);
  }

  persistTransactions();
  syncMonthFilterOptions();
  render();
  resetForm();
}

function handleAmountInput(event) {
  const input = event.target;
  const digitsBeforeCursor = countDigits(input.value.slice(0, input.selectionStart ?? 0));
  const numericValue = extractDigits(input.value);

  input.value = numericValue ? formatNumberWithCommas(numericValue) : "";

  const nextCursorPosition = getCursorPositionFromDigitIndex(input.value, digitsBeforeCursor);
  input.setSelectionRange(nextCursorPosition, nextCursorPosition);
}

function handleTodayButtonClick() {
  dateInput.value = getTodayString();
}

function handleNativeMonthFilterChange() {
  setPeriodValue(monthFilterInput.value, { closePanel: false });
}

function togglePeriodPanel() {
  if (!periodState.isPanelOpen) {
    syncPanelYearToCurrentSelection();
  }

  periodState.isPanelOpen = !periodState.isPanelOpen;
  syncPeriodUI();
}

function handleThisMonthClick() {
  const currentMonthValue = getCurrentMonthValue();
  periodState.panelYear = Number(currentMonthValue.split("-")[0]);
  setPeriodValue(currentMonthValue);
}

function changePanelYear(delta) {
  periodState.panelYear += delta;
  syncPeriodUI();
}

function handlePeriodMonthClick(event) {
  const button = event.target.closest("[data-period-value]");
  if (!button) {
    return;
  }

  setPeriodValue(button.dataset.periodValue);
}

function setPeriodValue(value, options = {}) {
  const { closePanel = true, skipRender = false } = options;
  const nextValue = value || "all";

  periodState.value = nextValue;
  syncPanelYearToCurrentSelection();
  monthFilterInput.value = nextValue;

  if (closePanel) {
    periodState.isPanelOpen = false;
  }

  syncMonthFilterOptions();
  syncPeriodUI();

  if (!skipRender) {
    render();
  }
}

function syncPanelYearToCurrentSelection() {
  periodState.panelYear = periodState.value === "all"
    ? getCurrentYear()
    : Number(periodState.value.split("-")[0]);
}

function syncPeriodUI() {
  selectedPeriodLabel.textContent = getSelectedPeriodLabel();
  periodToggleButton.textContent = periodState.isPanelOpen ? "기간 닫기" : "기간 선택";
  periodToggleButton.setAttribute("aria-expanded", String(periodState.isPanelOpen));
  periodSelectionPanel.classList.toggle("hidden", !periodState.isPanelOpen);
  periodPanelYearLabel.textContent = `${periodState.panelYear}년`;
  allTimeButton.classList.toggle("is-active", periodState.value === "all");
  thisMonthButton.classList.toggle("is-active", periodState.value === getCurrentMonthValue());
  renderPeriodMonthButtons();
}

function renderPeriodMonthButtons() {
  periodMonthGrid.innerHTML = Array.from({ length: 12 }, (_, index) => {
    const monthNumber = index + 1;
    const monthValue = `${periodState.panelYear}-${String(monthNumber).padStart(2, "0")}`;
    const isActive = monthValue === periodState.value;

    return `
      <button
        type="button"
        class="month-chip-button${isActive ? " is-active" : ""}"
        data-period-value="${monthValue}"
      >
        ${monthNumber}월
      </button>
    `;
  }).join("");
}

function getSelectedPeriodLabel() {
  return periodState.value === "all"
    ? "전체 기간"
    : formatMonthLabel(periodState.value);
}

function render() {
  syncMonthFilterOptions();
  syncPeriodUI();
  renderSummary();
  renderStatistics();
  renderTransactions();
}

function renderSummary() {
  const visibleTransactions = getVisibleTransactions();
  const totals = calculateSummaryTotals(visibleTransactions);
  const balance = totals.income - totals.expense;
  const variableExpense = totals.expense - totals.fixedExpense;

  totalIncomeElement.textContent = formatAmount(totals.income);
  totalExpenseElement.textContent = formatAmount(totals.expense);
  balanceElement.textContent = formatAmount(balance);
  totalFixedExpenseElement.textContent = formatAmount(totals.fixedExpense);
  totalVariableExpenseElement.textContent = formatAmount(variableExpense);
}

function renderTransactions() {
  const visibleTransactions = getVisibleTransactions();
  const hasTransactions = visibleTransactions.length > 0;

  emptyState.classList.toggle("hidden", hasTransactions);
  transactionCount.textContent = `${visibleTransactions.length}건`;

  if (!hasTransactions) {
    transactionList.innerHTML = "";
    return;
  }

  transactionList.innerHTML = getSortedTransactions(visibleTransactions)
    .map(
      (transaction) => `
        <tr>
          <td>${escapeHtml(transaction.date)}</td>
          <td>
            <span class="type-pill type-pill-${transaction.type}">
              ${transaction.type === "income" ? "수입" : "지출"}
            </span>
          </td>
          <td>${escapeHtml(transaction.category)}</td>
          <td>${transaction.type === "expense" && transaction.isFixed ? "고정" : "-"}</td>
          <td class="amount-${transaction.type}">
            ${transaction.type === "income" ? "+" : "-"}${formatAmount(transaction.amount)}
          </td>
          <td>${transaction.memo ? escapeHtml(transaction.memo) : "-"}</td>
          <td>
            <button type="button" class="edit-button" data-edit-id="${transaction.id}">
              수정
            </button>
            <button type="button" class="delete-button" data-delete-id="${transaction.id}">
              삭제
            </button>
          </td>
        </tr>
      `,
    )
    .join("");
}

function renderStatistics() {
  const statisticType = statisticsTypeInput.value;
  const visibleTransactions = getVisibleTransactions();

  if (statisticType === "all") {
    renderOverallStatistics(visibleTransactions);
    return;
  }

  const title = statisticType === "income" ? "수입" : "지출";
  const groupedStatistics = getCategoryStatistics(statisticType, visibleTransactions);
  const totalAmount = groupedStatistics.reduce((sum, item) => sum + item.amount, 0);

  chartTitle.textContent = title;
  chartTotal.textContent = formatAmount(totalAmount);
  statisticsEmpty.textContent = "선택한 유형에 대한 데이터가 아직 없습니다.";

  if (groupedStatistics.length === 0) {
    pieChart.style.background = "conic-gradient(#d8d1c6 0deg 360deg)";
    statisticsEmpty.classList.remove("hidden");
    statisticsList.classList.add("hidden");
    statisticsList.innerHTML = "";
    return;
  }

  pieChart.style.background = buildChartGradient(groupedStatistics, totalAmount);
  statisticsEmpty.classList.add("hidden");
  statisticsList.classList.remove("hidden");
  statisticsList.innerHTML = groupedStatistics
    .map(
      (item) => `
        <li class="statistics-item">
          <span class="statistics-swatch" style="background:${item.color}"></span>
          <span class="statistics-category">${escapeHtml(item.category)}</span>
          <span class="statistics-share">${item.share}%</span>
          <span class="statistics-amount">${formatAmount(item.amount)}</span>
        </li>
      `,
    )
    .join("");
}

function renderOverallStatistics(items) {
  const totals = calculateSummaryTotals(items);
  const totalFlow = totals.income + totals.expense;
  const balance = totals.income - totals.expense;
  const overallStatistics = [
    {
      category: "총수입",
      amount: totals.income,
      color: incomeChartColors[0],
      shareText: totalFlow > 0 ? `${Math.round((totals.income / totalFlow) * 100)}%` : "-",
    },
    {
      category: "총지출",
      amount: totals.expense,
      color: expenseChartColors[0],
      shareText: totalFlow > 0 ? `${Math.round((totals.expense / totalFlow) * 100)}%` : "-",
    },
    {
      category: "잔액",
      amount: balance,
      color: "#2e4f8f",
      shareText: "",
    },
  ];

  chartTitle.textContent = "전체";
  chartTotal.textContent = formatAmount(totalFlow);

  if (totals.income === 0 && totals.expense === 0) {
    pieChart.style.background = "conic-gradient(#d8d1c6 0deg 360deg)";
    statisticsEmpty.textContent = "선택한 기간에 수입과 지출 데이터가 없습니다.";
    statisticsEmpty.classList.remove("hidden");
    statisticsList.classList.add("hidden");
    statisticsList.innerHTML = "";
    return;
  }

  pieChart.style.background = buildChartGradient(
    overallStatistics.filter((item) => item.category !== "잔액" && item.amount > 0),
    totalFlow,
  );
  statisticsEmpty.classList.add("hidden");
  statisticsList.classList.remove("hidden");
  statisticsList.innerHTML = overallStatistics
    .map(
      (item) => `
        <li class="statistics-item">
          <span class="statistics-swatch" style="background:${item.color}"></span>
          <span class="statistics-category">${item.category}</span>
          <span class="statistics-share">${item.shareText}</span>
          <span class="statistics-amount">${formatAmount(item.amount)}</span>
        </li>
      `,
    )
    .join("");
}

function handleSummaryCardClick(event) {
  const card = event.target.closest("[data-summary-type]");
  if (!card) {
    return;
  }

  openSummaryModal(card.dataset.summaryType);
}

function handleSummaryCardKeydown(event) {
  const card = event.target.closest("[data-summary-type]");
  if (!card) {
    return;
  }

  if (event.key === "Enter" || event.key === " ") {
    event.preventDefault();
    openSummaryModal(card.dataset.summaryType);
  }
}

function openSummaryModal(summaryType) {
  const visibleTransactions = getVisibleTransactions();
  const totals = calculateSummaryTotals(visibleTransactions);
  const modalConfig = getSummaryModalConfig(summaryType, visibleTransactions, totals);

  modalTitle.textContent = modalConfig.title;
  modalTotal.textContent = formatAmount(modalConfig.total);

  if (modalConfig.kind === "balance") {
    modalBody.innerHTML = `
      <div class="modal-balance-box">
        <p>잔액 = 총수입 - 총지출</p>
        <div class="modal-balance-row">
          <span>총수입</span>
          <strong>${formatAmount(totals.income)}</strong>
        </div>
        <div class="modal-balance-row">
          <span>총지출</span>
          <strong>${formatAmount(totals.expense)}</strong>
        </div>
        <div class="modal-balance-row">
          <span>잔액</span>
          <strong>${formatAmount(totals.income - totals.expense)}</strong>
        </div>
      </div>
    `;
  } else if (modalConfig.transactions.length === 0) {
    modalBody.innerHTML = '<div class="modal-empty">현재 필터 기준으로 해당 내역이 없습니다.</div>';
  } else {
    modalBody.innerHTML = `
      <div class="modal-transaction-list">
        <div class="modal-transaction-head">
          <span>날짜</span>
          <span>카테고리</span>
          <span>메모</span>
          <span>금액</span>
        </div>
        ${modalConfig.transactions.map(renderModalTransactionItem).join("")}
      </div>
    `;
  }

  summaryModal.classList.remove("hidden");
  summaryModal.setAttribute("aria-hidden", "false");
}

function closeSummaryModal() {
  summaryModal.classList.add("hidden");
  summaryModal.setAttribute("aria-hidden", "true");
}

function handleModalOverlayClick(event) {
  if (event.target === summaryModal) {
    closeSummaryModal();
  }
}

function handleDocumentKeydown(event) {
  if (event.key === "Escape") {
    if (!summaryModal.classList.contains("hidden")) {
      closeSummaryModal();
      return;
    }

    if (periodState.isPanelOpen) {
      periodState.isPanelOpen = false;
      syncPeriodUI();
    }
  }
}

function handleTransactionAction(event) {
  const editButton = event.target.closest("[data-edit-id]");
  if (editButton) {
    startEditingTransaction(editButton.dataset.editId);
    return;
  }

  const deleteButton = event.target.closest("[data-delete-id]");
  if (!deleteButton) {
    return;
  }

  const shouldDelete = window.confirm("이 거래를 삭제하시겠습니까?");
  if (!shouldDelete) {
    return;
  }

  const { deleteId } = deleteButton.dataset;
  transactions = transactions.filter((transaction) => transaction.id !== deleteId);

  if (editingTransactionId === deleteId) {
    resetForm();
  }

  persistTransactions();
  syncMonthFilterOptions();
  render();
}

function updateCategoryOptions(type) {
  const categories = categoriesByType[type];
  categoryInput.innerHTML = categories
    .map((category) => `<option value="${category}">${category}</option>`)
    .join("");
}

function resetForm() {
  form.reset();
  editingTransactionId = null;
  formEyebrow.textContent = "내역 추가";
  formStatus.classList.add("hidden");
  cancelEditButton.classList.add("hidden");
  submitButton.textContent = "거래 추가";
  dateInput.value = getTodayString();
  typeInput.value = "expense";
  amountInput.value = "";
  isFixedInput.checked = false;
  updateCategoryOptions(typeInput.value);
  amountInput.focus();
}

function startEditingTransaction(transactionId) {
  const transaction = transactions.find((currentTransaction) => currentTransaction.id === transactionId);
  if (!transaction) {
    return;
  }

  editingTransactionId = transaction.id;
  formEyebrow.textContent = "내역 수정";
  formStatus.classList.remove("hidden");
  cancelEditButton.classList.remove("hidden");
  submitButton.textContent = "거래 수정";
  dateInput.value = transaction.date;
  typeInput.value = transaction.type;
  updateCategoryOptions(transaction.type);
  categoryInput.value = transaction.category;
  amountInput.value = formatNumberWithCommas(transaction.amount);
  memoInput.value = transaction.memo;
  isFixedInput.checked = Boolean(transaction.isFixed);
  amountInput.focus();
}

function persistTransactions() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(transactions));
}

function loadTransactions() {
  try {
    const storedValue = localStorage.getItem(STORAGE_KEY);
    if (!storedValue) {
      return [];
    }

    const parsedValue = JSON.parse(storedValue);
    if (!Array.isArray(parsedValue)) {
      return [];
    }

    return parsedValue.filter(isValidTransactionShape).map(normalizeTransaction);
  } catch (error) {
    console.error("localStorage에서 거래 데이터를 불러오지 못했습니다.", error);
    return [];
  }
}

function calculateSummaryTotals(items) {
  return items.reduce(
    (accumulator, transaction) => {
      if (transaction.type === "income") {
        accumulator.income += transaction.amount;
      } else {
        accumulator.expense += transaction.amount;
        if (transaction.isFixed) {
          accumulator.fixedExpense += transaction.amount;
        }
      }

      return accumulator;
    },
    { income: 0, expense: 0, fixedExpense: 0 },
  );
}

function isValidTransactionShape(transaction) {
  return (
    transaction &&
    typeof transaction.id === "string" &&
    typeof transaction.date === "string" &&
    (transaction.type === "income" || transaction.type === "expense") &&
    typeof transaction.amount === "number" &&
    typeof transaction.category === "string" &&
    typeof transaction.memo === "string" &&
    (typeof transaction.isFixed === "boolean" || typeof transaction.isFixed === "undefined")
  );
}

function normalizeTransaction(transaction) {
  return {
    ...transaction,
    isFixed: transaction.type === "expense" ? Boolean(transaction.isFixed) : false,
  };
}

function getTodayString() {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, "0");
  const day = String(today.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function getCurrentYear() {
  return new Date().getFullYear();
}

function getCurrentMonthValue() {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, "0");
  return `${year}-${month}`;
}

function formatAmount(value) {
  return new Intl.NumberFormat("ko-KR", {
    style: "currency",
    currency: "KRW",
    maximumFractionDigits: 0,
  }).format(value);
}

function escapeHtml(value) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function createTransactionId() {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }

  return `txn-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function getSortedTransactions(items = transactions) {
  return [...items].sort((left, right) => {
    const dateComparison = right.date.localeCompare(left.date);
    if (dateComparison !== 0) {
      return dateComparison;
    }

    return right.id.localeCompare(left.id);
  });
}

function getCategoryStatistics(type, items = transactions) {
  const colorPalette = type === "income" ? incomeChartColors : expenseChartColors;
  const categoryTotals = new Map();

  items.forEach((transaction) => {
    if (transaction.type !== type) {
      return;
    }

    categoryTotals.set(
      transaction.category,
      (categoryTotals.get(transaction.category) ?? 0) + transaction.amount,
    );
  });

  const totalAmount = [...categoryTotals.values()].reduce((sum, amount) => sum + amount, 0);

  return [...categoryTotals.entries()]
    .sort((left, right) => right[1] - left[1])
    .map(([category, amount], index) => ({
      category,
      amount,
      color: colorPalette[index % colorPalette.length],
      share: totalAmount === 0 ? 0 : Math.round((amount / totalAmount) * 100),
    }));
}

function buildChartGradient(statistics, totalAmount) {
  if (statistics.length === 0 || totalAmount <= 0) {
    return "conic-gradient(#d8d1c6 0deg 360deg)";
  }

  let currentAngle = 0;
  const segments = statistics.map((item, index) => {
    const segmentAngle = (item.amount / totalAmount) * 360;
    const startAngle = currentAngle;
    const endAngle = index === statistics.length - 1 ? 360 : currentAngle + segmentAngle;
    currentAngle = endAngle;
    return `${item.color} ${startAngle}deg ${endAngle}deg`;
  });

  return `conic-gradient(${segments.join(", ")})`;
}

function getFilteredTransactions() {
  const selectedMonth = monthFilterInput.value;
  if (!selectedMonth || selectedMonth === "all") {
    return transactions;
  }

  return transactions.filter((transaction) => transaction.date.startsWith(selectedMonth));
}

function getVisibleTransactions() {
  const searchTerm = transactionSearchInput.value.trim().toLowerCase();
  const monthFilteredTransactions = getFilteredTransactions();

  if (!searchTerm) {
    return monthFilteredTransactions;
  }

  return monthFilteredTransactions.filter((transaction) => {
    const typeLabel = transaction.type === "income" ? "수입" : "지출";
    return [
      transaction.memo,
      transaction.category,
      transaction.type,
      typeLabel,
    ].some((value) => value.toLowerCase().includes(searchTerm));
  });
}

function syncMonthFilterOptions() {
  const selectedValue = periodState.value || "all";
  const availableMonthSet = new Set(transactions.map((transaction) => transaction.date.slice(0, 7)));
  if (selectedValue !== "all") {
    availableMonthSet.add(selectedValue);
  }

  const availableMonths = [...availableMonthSet].sort((left, right) => right.localeCompare(left));
  monthFilterInput.innerHTML = [
    '<option value="all">전체 월</option>',
    ...availableMonths.map((month) => `<option value="${month}">${formatMonthLabel(month)}</option>`),
  ].join("");
  monthFilterInput.value = selectedValue;
}

function formatMonthLabel(monthValue) {
  const [year, month] = monthValue.split("-");
  return `${year}년 ${Number(month)}월`;
}

function getSummaryModalConfig(summaryType, items, totals) {
  switch (summaryType) {
    case "income":
      return {
        title: "총수입 상세",
        transactions: getSortedTransactions(items.filter((transaction) => transaction.type === "income")),
        total: totals.income,
        kind: "transactions",
      };
    case "expense":
      return {
        title: "총지출 상세",
        transactions: getSortedTransactions(items.filter((transaction) => transaction.type === "expense")),
        total: totals.expense,
        kind: "transactions",
      };
    case "fixedExpense":
      return {
        title: "총 고정지출 상세",
        transactions: getSortedTransactions(
          items.filter((transaction) => transaction.type === "expense" && transaction.isFixed),
        ),
        total: totals.fixedExpense,
        kind: "transactions",
      };
    case "variableExpense":
      return {
        title: "총 변동지출 상세",
        transactions: getSortedTransactions(
          items.filter((transaction) => transaction.type === "expense" && !transaction.isFixed),
        ),
        total: totals.expense - totals.fixedExpense,
        kind: "transactions",
      };
    case "balance":
      return {
        title: "잔액 상세",
        transactions: [],
        total: totals.income - totals.expense,
        kind: "balance",
      };
    default:
      return {
        title: "요약 상세",
        transactions: [],
        total: 0,
        kind: "transactions",
      };
  }
}

function renderModalTransactionItem(transaction) {
  return `
    <div class="modal-transaction-item">
      <span>${escapeHtml(transaction.date)}</span>
      <span>${escapeHtml(transaction.category)}</span>
      <span class="modal-transaction-memo">${transaction.memo ? escapeHtml(transaction.memo) : "-"}</span>
      <strong class="amount-${transaction.type}">
        ${transaction.type === "income" ? "+" : "-"}${formatAmount(transaction.amount)}
      </strong>
    </div>
  `;
}

function parseAmountInputValue(value) {
  const digits = extractDigits(value);
  return digits ? Number(digits) : Number.NaN;
}

function extractDigits(value) {
  return value.replace(/\D/g, "");
}

function formatNumberWithCommas(value) {
  return Number(value).toLocaleString("ko-KR");
}

function countDigits(value) {
  return extractDigits(value).length;
}

function getCursorPositionFromDigitIndex(formattedValue, digitIndex) {
  if (digitIndex <= 0) {
    return 0;
  }

  let digitsSeen = 0;
  for (let index = 0; index < formattedValue.length; index += 1) {
    if (/\d/.test(formattedValue[index])) {
      digitsSeen += 1;
    }

    if (digitsSeen >= digitIndex) {
      return index + 1;
    }
  }

  return formattedValue.length;
}
